package ro.sci.digitalCookBook.dao;

import ro.sci.digitalCookBook.domain.RecipeIngredient;

public interface RecipeIngredientDAO extends BaseDAO<RecipeIngredient> {

}
