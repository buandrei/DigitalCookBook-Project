package ro.sci.digitalCookBook.dao;

import ro.sci.digitalCookBook.domain.RecipePhoto;


public interface RecipePhotoDAO extends BaseDAO<RecipePhoto> {



}
