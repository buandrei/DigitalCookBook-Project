package ro.sci;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DigitalCookBookApplication {
    public static void main(String[] args) {

        SpringApplication.run(DigitalCookBookApplication.class, args);

    }
}
