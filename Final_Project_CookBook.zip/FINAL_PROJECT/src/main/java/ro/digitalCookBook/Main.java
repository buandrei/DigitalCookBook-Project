package ro.digitalCookBook;

public class Main {
}
